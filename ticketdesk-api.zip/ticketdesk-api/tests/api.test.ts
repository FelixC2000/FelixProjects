import bcrypt from "bcryptjs";
import { MongoMemoryServer } from "mongodb-memory-server";
import mongoose from "mongoose";
import request from "supertest";
import { afterAll, afterEach, beforeAll, describe, expect, it } from "vitest";
import { createApp } from "../src/app";
import { User } from "../src/models/User";

const app = createApp();
let mongod: MongoMemoryServer;

beforeAll(async () => {
  mongod = await MongoMemoryServer.create();
  await mongoose.connect(mongod.getUri());
  await User.init();
});

afterEach(async () => {
  const { collections } = mongoose.connection;
  await Promise.all(Object.values(collections).map((c) => c.deleteMany({})));
});

afterAll(async () => {
  await mongoose.disconnect();
  await mongod.stop();
});

async function registerCustomer(name: string, email: string) {
  const res = await request(app).post("/api/auth/register").send({ name, email, password: "password123" });
  return { token: res.body.token as string, id: res.body.user.id as string };
}

async function createAgent() {
  await User.create({
    name: "Ann Agent",
    email: "agent@example.com",
    passwordHash: await bcrypt.hash("password123", 4),
    role: "agent",
  });
  const res = await request(app).post("/api/auth/login").send({ email: "agent@example.com", password: "password123" });
  return { token: res.body.token as string, id: res.body.user.id as string };
}

const auth = (token: string) => ({ Authorization: `Bearer ${token}` });

const ticketBody = {
  title: "Blender will not turn on",
  description: "I plugged it in and pressed the power button but nothing happens.",
  priority: "high",
};

describe("auth", () => {
  it("registers, then logs in", async () => {
    const reg = await request(app).post("/api/auth/register").send({ name: "Felix", email: "felix@example.com", password: "password123" });
    expect(reg.status).toBe(201);
    expect(reg.body.user.role).toBe("customer");
    expect(reg.body.user.passwordHash).toBeUndefined();

    const login = await request(app).post("/api/auth/login").send({ email: "felix@example.com", password: "password123" });
    expect(login.status).toBe(200);
    expect(login.body.token).toBeTypeOf("string");
  });

  it("rejects duplicate emails and bad credentials", async () => {
    await registerCustomer("Felix", "felix@example.com");
    const dup = await request(app).post("/api/auth/register").send({ name: "Felix", email: "felix@example.com", password: "password123" });
    expect(dup.status).toBe(409);

    const bad = await request(app).post("/api/auth/login").send({ email: "felix@example.com", password: "wrong-password" });
    expect(bad.status).toBe(401);
  });

  it("returns 400 with details for invalid input", async () => {
    const res = await request(app).post("/api/auth/register").send({ name: "F", email: "nope", password: "1" });
    expect(res.status).toBe(400);
    expect(res.body.details.email).toBeDefined();
  });
});

describe("tickets", () => {
  it("requires authentication", async () => {
    expect((await request(app).get("/api/tickets")).status).toBe(401);
  });

  it("lets customers create tickets and only see their own", async () => {
    const alice = await registerCustomer("Alice", "alice@example.com");
    const bob = await registerCustomer("Bob", "bob@example.com");

    const created = await request(app).post("/api/tickets").set(auth(alice.token)).send(ticketBody);
    expect(created.status).toBe(201);
    expect(created.body.status).toBe("open");

    const aliceList = await request(app).get("/api/tickets").set(auth(alice.token));
    expect(aliceList.body.total).toBe(1);

    const bobList = await request(app).get("/api/tickets").set(auth(bob.token));
    expect(bobList.body.total).toBe(0);

    const bobDirect = await request(app).get(`/api/tickets/${created.body._id}`).set(auth(bob.token));
    expect(bobDirect.status).toBe(404);
  });

  it("only lets agents update status and assign tickets", async () => {
    const alice = await registerCustomer("Alice", "alice@example.com");
    const agent = await createAgent();
    const created = await request(app).post("/api/tickets").set(auth(alice.token)).send(ticketBody);
    const url = `/api/tickets/${created.body._id}`;

    const denied = await request(app).patch(url).set(auth(alice.token)).send({ status: "closed" });
    expect(denied.status).toBe(403);

    const updated = await request(app).patch(url).set(auth(agent.token)).send({ status: "in_progress", assignee: agent.id });
    expect(updated.status).toBe(200);
    expect(updated.body.status).toBe("in_progress");
    expect(updated.body.assignee).toBe(agent.id);

    const badAssignee = await request(app).patch(url).set(auth(agent.token)).send({ assignee: alice.id });
    expect(badAssignee.status).toBe(400);
  });

  it("supports comments from the requester and agents, and filtering", async () => {
    const alice = await registerCustomer("Alice", "alice@example.com");
    const agent = await createAgent();
    const created = await request(app).post("/api/tickets").set(auth(alice.token)).send(ticketBody);
    const url = `/api/tickets/${created.body._id}`;

    await request(app).post(`${url}/comments`).set(auth(alice.token)).send({ body: "Any update?" });
    const withReply = await request(app).post(`${url}/comments`).set(auth(agent.token)).send({ body: "Looking into it." });
    expect(withReply.status).toBe(201);
    expect(withReply.body.comments).toHaveLength(2);

    const filtered = await request(app).get("/api/tickets?status=resolved").set(auth(agent.token));
    expect(filtered.body.total).toBe(0);
    const high = await request(app).get("/api/tickets?priority=high").set(auth(agent.token));
    expect(high.body.total).toBe(1);
  });

  it("rejects malformed ids", async () => {
    const alice = await registerCustomer("Alice", "alice@example.com");
    const res = await request(app).get("/api/tickets/not-an-id").set(auth(alice.token));
    expect(res.status).toBe(400);
  });
});
