import { describe, expect, it } from "vitest";
import { createTicketSchema, listQuerySchema, registerSchema, updateTicketSchema } from "../src/schemas";

describe("registerSchema", () => {
  it("normalizes email casing and whitespace", () => {
    const result = registerSchema.parse({ name: "Felix", email: "  Felix@Example.COM ", password: "password123" });
    expect(result.email).toBe("felix@example.com");
  });

  it("rejects short passwords", () => {
    expect(registerSchema.safeParse({ name: "Felix", email: "f@example.com", password: "short" }).success).toBe(false);
  });
});

describe("createTicketSchema", () => {
  it("defaults priority to medium", () => {
    const result = createTicketSchema.parse({ title: "Blender won't start", description: "It does nothing when I press power." });
    expect(result.priority).toBe("medium");
  });

  it("rejects too-short descriptions", () => {
    expect(createTicketSchema.safeParse({ title: "Help", description: "short" }).success).toBe(false);
  });
});

describe("updateTicketSchema", () => {
  it("requires at least one field", () => {
    expect(updateTicketSchema.safeParse({}).success).toBe(false);
  });

  it("rejects invalid statuses and ids", () => {
    expect(updateTicketSchema.safeParse({ status: "banana" }).success).toBe(false);
    expect(updateTicketSchema.safeParse({ assignee: "not-an-id" }).success).toBe(false);
  });

  it("allows unassigning with null", () => {
    expect(updateTicketSchema.parse({ assignee: null })).toEqual({ assignee: null });
  });
});

describe("listQuerySchema", () => {
  it("applies pagination defaults and coerces strings", () => {
    expect(listQuerySchema.parse({})).toEqual({ page: 1, limit: 20 });
    expect(listQuerySchema.parse({ page: "2", limit: "5" })).toEqual({ page: 2, limit: 5 });
  });

  it("caps limit at 100", () => {
    expect(listQuerySchema.safeParse({ limit: "500" }).success).toBe(false);
  });
});
