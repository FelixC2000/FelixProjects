import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    environment: "node",
    hookTimeout: 60_000,
    env: {
      NODE_ENV: "test",
      MONGODB_URI: "mongodb://localhost:27017/ticketdesk-test",
      JWT_SECRET: "test-secret-that-is-long-enough",
    },
  },
});
