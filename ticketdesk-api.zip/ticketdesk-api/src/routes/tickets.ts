import { Router } from "express";
import { currentUser, requireAuth, requireRole } from "../middleware/auth";
import { Ticket } from "../models/Ticket";
import { User } from "../models/User";
import {
  commentSchema,
  createTicketSchema,
  idParamSchema,
  listQuerySchema,
  updateTicketSchema,
} from "../schemas";
import { asyncHandler } from "../utils/asyncHandler";
import { HttpError } from "../utils/errors";
import type { Role } from "../constants";
import { Types } from "mongoose";

export const ticketsRouter = Router();
ticketsRouter.use(requireAuth);

/**
 * Customers can only access their own tickets; agents can access all of them.
 * A 404 (not 403) is returned for other people's tickets so ids can't be probed.
 */
async function findAccessibleTicket(id: string, user: { id: string; role: Role }) {
  const ticket = await Ticket.findById(id);
  if (!ticket || (user.role === "customer" && ticket.requester.toString() !== user.id)) {
    throw new HttpError(404, "Ticket not found");
  }
  return ticket;
}

ticketsRouter.get(
  "/",
  asyncHandler(async (req, res) => {
    const user = currentUser(req);
    const { status, priority, page, limit } = listQuerySchema.parse(req.query);

    const filter: Record<string, unknown> = {};
    if (status) filter.status = status;
    if (priority) filter.priority = priority;
    if (user.role === "customer") filter.requester = user.id;

    const [data, total] = await Promise.all([
      Ticket.find(filter)
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit),
      Ticket.countDocuments(filter),
    ]);

    res.json({ data, page, limit, total, totalPages: Math.ceil(total / limit) });
  }),
);

ticketsRouter.post(
  "/",
  asyncHandler(async (req, res) => {
    const user = currentUser(req);
    const input = createTicketSchema.parse(req.body);
    const ticket = await Ticket.create({ ...input, requester: user.id });
    res.status(201).json(ticket);
  }),
);

ticketsRouter.get(
  "/:id",
  asyncHandler(async (req, res) => {
    const { id } = idParamSchema.parse(req.params);
    const ticket = await findAccessibleTicket(id, currentUser(req));
    res.json(ticket);
  }),
);

// Agents only: change status/priority or assign the ticket to an agent.
ticketsRouter.patch(
  "/:id",
  requireRole("agent"),
  asyncHandler(async (req, res) => {
    const { id } = idParamSchema.parse(req.params);
    const updates = updateTicketSchema.parse(req.body);
    const ticket = await findAccessibleTicket(id, currentUser(req));

    if (updates.assignee) {
      const agent = await User.findOne({ _id: updates.assignee, role: "agent" });
      if (!agent) throw new HttpError(400, "Assignee must be an existing agent");
    }

    ticket.set(updates);
    await ticket.save();
    res.json(ticket);
  }),
);

ticketsRouter.post(
  "/:id/comments",
  asyncHandler(async (req, res) => {
    const user = currentUser(req);
    const { id } = idParamSchema.parse(req.params);
    const { body } = commentSchema.parse(req.body);
    await findAccessibleTicket(id, user);

    const updated = await Ticket.findByIdAndUpdate(
      id,
      { $push: { comments: { author: new Types.ObjectId(user.id), body } } },
      { new: true },
    );
    res.status(201).json(updated);
  }),
);

ticketsRouter.delete(
  "/:id",
  requireRole("agent"),
  asyncHandler(async (req, res) => {
    const { id } = idParamSchema.parse(req.params);
    const result = await Ticket.findByIdAndDelete(id);
    if (!result) throw new HttpError(404, "Ticket not found");
    res.status(204).send();
  }),
);
