import bcrypt from "bcryptjs";
import { Router } from "express";
import { User } from "../models/User";
import { loginSchema, registerSchema } from "../schemas";
import { asyncHandler } from "../utils/asyncHandler";
import { HttpError } from "../utils/errors";
import { signToken } from "../utils/jwt";

export const authRouter = Router();

function toPublicUser(user: InstanceType<typeof User>) {
  return { id: user.id as string, name: user.name, email: user.email, role: user.role };
}

// Self-registration always creates a "customer". Agents are created with `npm run create-agent`.
authRouter.post(
  "/register",
  asyncHandler(async (req, res) => {
    const { name, email, password } = registerSchema.parse(req.body);

    if (await User.exists({ email })) {
      throw new HttpError(409, "Email is already registered");
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, passwordHash, role: "customer" });

    res.status(201).json({
      user: toPublicUser(user),
      token: signToken({ sub: user.id, role: "customer" }),
    });
  }),
);

authRouter.post(
  "/login",
  asyncHandler(async (req, res) => {
    const { email, password } = loginSchema.parse(req.body);

    const user = await User.findOne({ email });
    const valid = user ? await bcrypt.compare(password, user.passwordHash) : false;
    if (!user || !valid) {
      // Same message for both cases so the API doesn't reveal which emails exist.
      throw new HttpError(401, "Invalid email or password");
    }

    res.json({
      user: toPublicUser(user),
      token: signToken({ sub: user.id, role: user.role as "customer" | "agent" }),
    });
  }),
);
