import mongoose from "mongoose";
import { createApp } from "./app";
import { config } from "./config";

async function main() {
  await mongoose.connect(config.MONGODB_URI);
  console.log("Connected to MongoDB");

  const server = createApp().listen(config.PORT, () => {
    console.log(`TicketDesk API listening on http://localhost:${config.PORT}`);
  });

  const shutdown = async (signal: string) => {
    console.log(`${signal} received, shutting down`);
    server.close(async () => {
      await mongoose.disconnect();
      process.exit(0);
    });
  };
  process.on("SIGINT", () => void shutdown("SIGINT"));
  process.on("SIGTERM", () => void shutdown("SIGTERM"));
}

main().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
