import cors from "cors";
import express from "express";
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import { config } from "./config";
import { errorHandler, notFound } from "./middleware/error";
import { authRouter } from "./routes/auth";
import { ticketsRouter } from "./routes/tickets";

export function createApp() {
  const app = express();

  app.use(helmet());
  app.use(cors());
  app.use(express.json({ limit: "100kb" }));

  app.get("/health", (_req, res) => {
    res.json({ status: "ok", uptime: process.uptime() });
  });

  // Slow down brute-force attempts on login/register.
  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 100,
    standardHeaders: true,
    legacyHeaders: false,
    skip: () => config.NODE_ENV === "test",
  });

  app.use("/api/auth", authLimiter, authRouter);
  app.use("/api/tickets", ticketsRouter);

  app.use(notFound);
  app.use(errorHandler);

  return app;
}
