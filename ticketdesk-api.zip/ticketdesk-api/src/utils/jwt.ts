import jwt from "jsonwebtoken";
import { config } from "../config";
import { ROLES, type Role } from "../constants";

export interface TokenPayload {
  sub: string;
  role: Role;
}

export function signToken(payload: TokenPayload): string {
  return jwt.sign(payload, config.JWT_SECRET, {
    expiresIn: config.JWT_EXPIRES_IN as jwt.SignOptions["expiresIn"],
  });
}

export function verifyToken(token: string): TokenPayload {
  const decoded = jwt.verify(token, config.JWT_SECRET);
  if (typeof decoded === "string" || typeof decoded.sub !== "string" || !ROLES.includes(decoded.role)) {
    throw new Error("Malformed token");
  }
  return { sub: decoded.sub, role: decoded.role as Role };
}
