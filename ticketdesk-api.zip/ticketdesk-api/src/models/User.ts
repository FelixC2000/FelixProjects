import { Schema, model } from "mongoose";
import { ROLES } from "../constants";

const userSchema = new Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true },
    role: { type: String, enum: [...ROLES], default: "customer" },
  },
  { timestamps: true },
);

export const User = model("User", userSchema);
