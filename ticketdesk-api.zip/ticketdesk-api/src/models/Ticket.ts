import { Schema, model } from "mongoose";
import { TICKET_PRIORITIES, TICKET_STATUSES } from "../constants";

const commentSchema = new Schema(
  {
    author: { type: Schema.Types.ObjectId, ref: "User", required: true },
    body: { type: String, required: true, trim: true },
  },
  { timestamps: { createdAt: true, updatedAt: false } },
);

const ticketSchema = new Schema(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, required: true, trim: true },
    status: { type: String, enum: [...TICKET_STATUSES], default: "open" },
    priority: { type: String, enum: [...TICKET_PRIORITIES], default: "medium" },
    requester: { type: Schema.Types.ObjectId, ref: "User", required: true, index: true },
    assignee: { type: Schema.Types.ObjectId, ref: "User", default: null },
    comments: { type: [commentSchema], default: [] },
  },
  { timestamps: true },
);

ticketSchema.index({ status: 1, priority: 1, createdAt: -1 });

export const Ticket = model("Ticket", ticketSchema);
