import bcrypt from "bcryptjs";
import mongoose from "mongoose";
import { config } from "../src/config";
import { User } from "../src/models/User";

// Usage: npm run create-agent -- "Ann Agent" ann@example.com "a-strong-password"
async function main() {
  const [name, email, password] = process.argv.slice(2);
  if (!name || !email || !password || password.length < 8) {
    console.error('Usage: npm run create-agent -- "<name>" <email> "<password (8+ chars)>"');
    process.exit(1);
  }

  await mongoose.connect(config.MONGODB_URI);
  const existing = await User.findOne({ email: email.toLowerCase() });
  if (existing) {
    existing.role = "agent";
    await existing.save();
    console.log(`Promoted existing user ${email} to agent`);
  } else {
    await User.create({
      name,
      email: email.toLowerCase(),
      passwordHash: await bcrypt.hash(password, 10),
      role: "agent",
    });
    console.log(`Created agent ${email}`);
  }
  await mongoose.disconnect();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
