# TicketDesk API

A TypeScript REST API for a customer support ticket system. Customers open tickets and follow up with comments; support agents triage, assign, and resolve them.

I built this because I work in technical support every day, so I wanted to model the workflow I actually use (tickets, statuses, priorities, follow-ups) with a clean, tested backend.

## Features

- **JWT authentication** with bcrypt password hashing
- **Role-based access control** (`customer` and `agent`)
  - Customers can only see and comment on their own tickets
  - Agents can see all tickets, change status/priority, assign tickets, and delete them
- **Ticket lifecycle**: `open` → `in_progress` → `resolved` → `closed`, with `low`/`medium`/`high` priority
- **Comment threads** on each ticket
- **Filtering and pagination** (`?status=open&priority=high&page=2&limit=20`)
- **Runtime validation** with Zod, returning clear 400 errors with per-field details
- **Centralized error handling**, security headers (Helmet), CORS, and rate limiting on auth routes
- **Typed environment config**: the app refuses to start with a missing or weak `JWT_SECRET`
- **Integration tests** (Vitest + Supertest) against an in-memory MongoDB, plus GitHub Actions CI

## Tech stack

TypeScript (strict mode), Node.js, Express, MongoDB + Mongoose, Zod, JSON Web Tokens, Vitest, Supertest

## Getting started

Requirements: Node.js 20+ and a MongoDB instance (local or [MongoDB Atlas](https://www.mongodb.com/atlas)).

```bash
git clone https://github.com/<your-username>/ticketdesk-api.git
cd ticketdesk-api
npm install
cp .env.example .env      # then edit MONGODB_URI and JWT_SECRET
npm run dev
```

The API runs at `http://localhost:3000`. Check `GET /health`.

### Creating an agent

Registration always creates a `customer` so nobody can sign themselves up as staff. Create an agent from the command line:

```bash
npm run create-agent -- "Ann Agent" ann@example.com "a-strong-password"
```

### Scripts

| Script | What it does |
| --- | --- |
| `npm run dev` | Start with auto-reload |
| `npm test` | Run the test suite |
| `npm run typecheck` | Type-check without emitting |
| `npm run build` / `npm start` | Compile to `dist/` and run |

## API

All `/api/tickets` routes require an `Authorization: Bearer <token>` header.

| Method | Route | Access | Description |
| --- | --- | --- | --- |
| POST | `/api/auth/register` | Public | Create a customer account, returns a token |
| POST | `/api/auth/login` | Public | Log in, returns a token |
| GET | `/api/tickets` | Customer/Agent | List tickets (customers see only their own) |
| POST | `/api/tickets` | Customer/Agent | Create a ticket |
| GET | `/api/tickets/:id` | Owner/Agent | Get one ticket |
| PATCH | `/api/tickets/:id` | Agent | Update `status`, `priority`, or `assignee` |
| POST | `/api/tickets/:id/comments` | Owner/Agent | Add a comment |
| DELETE | `/api/tickets/:id` | Agent | Delete a ticket |

### Example

```bash
# Register
curl -X POST localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Felix","email":"felix@example.com","password":"password123"}'

# Create a ticket (use the token from above)
curl -X POST localhost:3000/api/tickets \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"title":"Blender will not turn on","description":"Nothing happens when I press power.","priority":"high"}'
```

## Project structure

```
src/
  app.ts            Express app factory (middleware + routes)
  server.ts         Entry point: DB connection and graceful shutdown
  config.ts         Validated environment variables
  schemas.ts        Zod schemas for every request body/query/param
  models/           Mongoose models (User, Ticket)
  routes/           auth and tickets routers
  middleware/       auth/role guards and error handling
  utils/            JWT helpers, HttpError, asyncHandler
tests/              Unit tests for schemas + API integration tests
scripts/            create-agent CLI
```

## Design decisions

- **`createApp()` is separate from `server.ts`** so tests can import the app without opening a port or a real database connection.
- **Zod is the single source of truth for input shape.** Every route parses its input before touching the database.
- **Other users' tickets return 404, not 403**, so ticket ids can't be probed.
- **Login errors are generic** ("Invalid email or password") so the API doesn't reveal which emails are registered.

## Ideas for future improvements

- Refresh tokens and password reset via email
- Email notifications when an agent replies
- SLA timers (flag high-priority tickets not answered within N hours)
- OpenAPI/Swagger docs
- A React frontend (dashboard for agents, portal for customers)

## License

MIT
